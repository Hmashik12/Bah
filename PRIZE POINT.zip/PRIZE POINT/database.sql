CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `telegram_id` BIGINT UNIQUE NOT NULL,
  `first_name` VARCHAR(255) NOT NULL,
  `username` VARCHAR(255),
  `balance` DECIMAL(10, 4) DEFAULT 0.0000,
  `total_ads_watched` INT DEFAULT 0,
  `today_ads_watched` INT DEFAULT 0,
  `last_ad_date` DATE,
  `total_withdrawals` DECIMAL(10, 4) DEFAULT 0.0000,
  `referral_count` INT DEFAULT 0,
  `total_clicks` INT DEFAULT 0,
  `wrong_clicks` INT DEFAULT 0,
  `today_clicks` INT DEFAULT 0,
  `referrer_id` BIGINT,
  `join_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `country` VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `withdrawal_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` BIGINT NOT NULL,
  `amount` DECIMAL(10, 4) NOT NULL,
  `method` VARCHAR(50) NOT NULL,
  `address` VARCHAR(255) NOT NULL,
  `status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
  `request_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `processed_at` TIMESTAMP NULL,
  `admin_notes` TEXT,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`telegram_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;