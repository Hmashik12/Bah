<?php
require 'db_connect.php';

if (!isset($_GET['user_id']) {
    echo json_encode(['success' => false, 'message' => 'User ID not provided.']);
    exit();
}

$user_id = $_GET['user_id'];
$click_type = $_GET['click_type'] ?? 'none'; // 'right', 'wrong', or 'none'
$today = date('Y-m-d');

$conn->begin_transaction();

try {
    // Check user status and click eligibility
    $user_stmt = $conn->prepare("SELECT * FROM users WHERE telegram_id = ?");
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user = $user_stmt->get_result()->fetch_assoc();
    
    if (!$user) throw new Exception('User not found.');
    if ($user['is_blocked']) throw new Exception('Your account is blocked.');
    
    // Update click counts
    $click_updates = "";
    if ($click_type === 'right') {
        $click_updates = "total_clicks = total_clicks + 1, today_clicks = today_clicks + 1,";
    } elseif ($click_type === 'wrong') {
        $click_updates = "wrong_clicks = wrong_clicks + 1,";
    }
    
    // Only reward after 5 right clicks
    $reward = ($user['today_clicks'] % 5 === 0 && $click_type === 'right') ? 0.01 : 0;
    
    $update_stmt = $conn->prepare(
        "UPDATE users SET 
            balance = balance + ?,
            total_ads_watched = total_ads_watched + 1,
            today_ads_watched = today_ads_watched + 1,
            last_ad_date = ?,
            {$click_updates}
            last_click_time = NOW()
        WHERE telegram_id = ?"
    );
    $update_stmt->bind_param("dsi", $reward, $today, $user_id);
    $update_stmt->execute();
    
    // Fetch updated user data
    $user_stmt->execute();
    $updated_user = $user_stmt->get_result()->fetch_assoc();
    
    $conn->commit();
    echo json_encode(['success' => true, 'user_data' => $updated_user, 'rewarded' => $reward > 0]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();