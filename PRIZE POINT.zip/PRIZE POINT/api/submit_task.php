<?php
require 'db_connect.php';

if (!isset($_POST['user_id']) || !isset($_POST['task_id']) || !isset($_POST['submitted_data'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required data.']);
    exit();
}

$user_id = $_POST['user_id'];
$task_id = $_POST['task_id'];
$submitted_data = $_POST['submitted_data'];

$conn->begin_transaction();

try {
    // Check if task exists and is active
    $task_stmt = $conn->prepare("SELECT * FROM tasks WHERE id = ? AND is_active = TRUE");
    $task_stmt->bind_param("i", $task_id);
    $task_stmt->execute();
    $task = $task_stmt->get_result()->fetch_assoc();
    
    if (!$task) throw new Exception('Task not found or inactive.');
    
    // Check if user already submitted this task
    $existing_stmt = $conn->prepare("SELECT id FROM user_tasks WHERE user_id = ? AND task_id = ?");
    $existing_stmt->bind_param("ii", $user_id, $task_id);
    $existing_stmt->execute();
    
    if ($existing_stmt->get_result()->num_rows > 0) {
        throw new Exception('You have already submitted this task.');
    }
    
    // Create submission
    $insert_stmt = $conn->prepare(
        "INSERT INTO user_tasks (user_id, task_id, submitted_data, status, submitted_at)
         VALUES (?, ?, ?, 'pending', NOW())"
    );
    $insert_stmt->bind_param("iis", $user_id, $task_id, $submitted_data);
    $insert_stmt->execute();
    
    $conn->commit();
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();