<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$user_id = $_GET['user_id'] ?? null;

if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'User ID required']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            id, 
            amount, 
            method, 
            address, 
            status, 
            DATE_FORMAT(request_date, '%Y-%m-%d %H:%i:%s') as request_date,
            DATE_FORMAT(processed_at, '%Y-%m-%d %H:%i:%s') as processed_date
        FROM withdrawal_history 
        WHERE user_id = ?
        ORDER BY request_date DESC
        LIMIT 50
    ");
    $stmt->execute([$user_id]);
    
    echo json_encode([
        'success' => true,
        'withdrawals' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>