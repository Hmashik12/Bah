<?php
header('Content-Type: application/json');
require_once 'db_connect.php';

$input = json_decode(file_get_contents('php://input'), true);
$user_id = $input['user_id'] ?? $_GET['user_id'] ?? null;
$amount = $input['amount'] ?? $_GET['amount'] ?? null;
$method = $input['method'] ?? $_GET['method'] ?? null;
$address = $input['address'] ?? $_GET['address'] ?? null;

if (!$user_id || !$amount || !$method || !$address) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Check user balance
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE telegram_id = ? FOR UPDATE");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception("User not found");
    }

    if ($user['balance'] < $amount) {
        throw new Exception("Insufficient balance");
    }

    // Deduct from balance
    $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE telegram_id = ?");
    $stmt->execute([$amount, $user_id]);

    // Create withdrawal record
    $stmt = $pdo->prepare("
        INSERT INTO withdrawal_history 
        (user_id, amount, method, address) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $amount, $method, $address]);

    // Update total withdrawals (separate query for clarity)
    $stmt = $pdo->prepare("UPDATE users SET total_withdrawals = total_withdrawals + ? WHERE telegram_id = ?");
    $stmt->execute([$amount, $user_id]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Withdrawal request submitted',
        'new_balance' => $user['balance'] - $amount,
        'new_total_withdrawals' => $user['total_withdrawals'] + $amount
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>