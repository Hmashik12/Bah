<?php
require 'db_connect.php';

if (!isset($_GET['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User ID not provided.']);
    exit();
}

$user_id = $_GET['user_id'];

// Get active tasks not yet completed by user
$query = "
    SELECT t.*, 
           ut.status AS user_status,
           ut.submitted_at,
           ut.processed_at
    FROM tasks t
    LEFT JOIN user_tasks ut ON t.id = ut.task_id AND ut.user_id = ?
    WHERE t.is_active = TRUE
    ORDER BY t.created_at DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$tasks = [];
while ($row = $result->fetch_assoc()) {
    $tasks[] = $row;
}

echo json_encode(['success' => true, 'tasks' => $tasks]);
$conn->close();