<?php
require 'db_connect.php';

// Check if user_data is provided
if (!isset($_GET['user_data'])) {
    echo json_encode(['success' => false, 'message' => 'User data not provided.']);
    exit();
}

$userData = json_decode($_GET['user_data'], true);
$start_param = $_GET['start_param'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'];

// Check for VPN/Proxy
$vpn_check = @json_decode(file_get_contents("http://ip-api.com/json/{$ip}"), true);
$is_vpn = ($vpn_check['proxy'] || $vpn_check['hosting']);

if ($is_vpn) {
    echo json_encode(['success' => false, 'is_blocked' => true, 'message' => 'VPN detected. Please disable VPN to use this app.']);
    exit();
}

// Rest of the user data processing...